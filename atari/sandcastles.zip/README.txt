Thank you for downloading Sand Castles for Atari 2600!

"sandcastles.bin" is the game's ROM file and should be playable in many Atari 2600 VCS emulators such as Stella (available here: https://stella-emu.github.io/)

For details on gameplay, please view the included manual PDF. In summary: jump and shoot the enemies to clear each level - but don't take too long or you'll get chased by the "reaper". Left difficulty switch controls game difficulty, right switch turns music on/off. This game is also compatible with SEGA Genesis controllers!

If you are interested in obtaining a physical copy of Sand Castles, or any of my Atari 2600 games - please contact me via metalbabble.com 

Have fun!
-------------------------------------
http://www.metalbabble.com/